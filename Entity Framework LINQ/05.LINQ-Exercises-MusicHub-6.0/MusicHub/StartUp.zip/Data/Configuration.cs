﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=IORDAN\SQLEXPRESS;Database=MusicHub;Integrated Security=True";
    }
}
