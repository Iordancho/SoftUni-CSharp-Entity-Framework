﻿namespace P02_FootballBetting
{
    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}

